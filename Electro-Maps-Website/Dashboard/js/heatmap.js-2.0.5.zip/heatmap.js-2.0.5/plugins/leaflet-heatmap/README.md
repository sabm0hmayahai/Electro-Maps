This is a heatmap.js plugin to visualize data as a **heatmap overlay with Leaflet**.


Learn more about how to use heatmap.js and this overlay implementation on the [heatmap website](https://www.patrick-wied.at/static/heatmapjs/?utm_source=npm_leaflet&utm_medium=web)